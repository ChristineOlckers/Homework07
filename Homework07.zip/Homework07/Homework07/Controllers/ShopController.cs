﻿using Homework07.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Homework07.Controllers
{
    public class ShopController : Controller
    {
        // GET: Shop
        public ActionResult Index()
        {
            List<ShopItemViewModel> lstItems = new List<ShopItemViewModel>()
            {
                new ShopItemViewModel() {Name = "Saddle", Description = "Black Leather, English cut", Price = 4890, QuantityAvailable = 3 },
                new ShopItemViewModel() {Name = "Boots", Description = "Italian Leather, Tan coloured", Price = 3000, QuantityAvailable = 6 },
                new ShopItemViewModel() {Name = "Bridle", Description = "Black Leather, Studded head piece", Price = 1500, QuantityAvailable = 5 },
            };

            /*  Vir die database
             *       
             *       SqlConnection Con = new SqlConnection();
       string path = ConfigurationManager.ConnectionStrings["dbpath"].ConnectionString;
       Con.ConnectionString = path;
       DataTable dt = new DataTable();
       try
       {
           SqlDataAdapter adp = new SqlDataAdapter("select * from UserData",Con);
           adp.Fill(dt);
       }
       catch (Exception)
       {
           throw;
       } */

            return View(lstItems);
        }

        public ActionResult AddItem()
        {
            return View();
        }

        public ActionResult Part2()
        {
            return View();
        }
    }
}


