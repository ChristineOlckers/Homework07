﻿CREATE TABLE dbo.[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(20) NOT NULL, 
    [Description] NCHAR(50) NOT NULL, 
    [QuantityAvailable] INT NOT NULL DEFAULT 0, 
    [Price] FLOAT NOT NULL DEFAULT 0
)
